<?php
session_start();
if (!isset($_SESSION['userid'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Inicial</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            text-align: center;
            padding: 50px;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: inline-block;
        }
        a {
            color: #4B0082; /* Roxo */
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            color: #0000FF; /* Azul */
        }
    </style>
</head>
<body>
<div class="container">
Bem-vindo, <?php echo $_SESSION['username']; ?>!
<br>
<hr>
<br>
<a href="logout.php">Sair</a>

</div>
</body>
</html>


