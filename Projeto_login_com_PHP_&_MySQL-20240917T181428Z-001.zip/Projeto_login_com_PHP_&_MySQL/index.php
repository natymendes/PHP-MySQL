<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            text-align: center;
            padding: 50px;
        }
        h1 {
            color: #4B0082; /* Roxo */
        }
        p {
            font-size: 18px;
        }
        a {
            color: #0000FF; /* Azul */
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h1>AUTENTICAÇÃO DE USUÁRIOS</h1>
    <p>Já possuo cadastro <a href="login.php">FAZER LOGIN</a></p>
    <p>Não possuo cadastro <a href="cadastroUsuario.php">ME CADASTRAR</a></p>
</body>
</html>
