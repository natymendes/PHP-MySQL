<?php
session_start();
include 'conexao.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $senha = $_POST['senha'];

    $sql = "SELECT * FROM usuarios WHERE nome='$nome'";
    $result = $conexao->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($senha, $row['senha'])) {
            $_SESSION['userid'] = $row['id'];
            $_SESSION['username'] = $row['nome'];
            header("Location: areaRestrita.php");
        } else {
            echo "Senha incorreta!";
        }
    } else { 
        echo "Usuário não encontrado!";
    }
}
?>
